package com.opsc7312.quizwizapp

data class TrueOrFalseQuestion(
    val questionText: String,
    val correctAnswer: Boolean,
    val incorrectAnswer: Boolean // Or a String for the incorrect answer
)
