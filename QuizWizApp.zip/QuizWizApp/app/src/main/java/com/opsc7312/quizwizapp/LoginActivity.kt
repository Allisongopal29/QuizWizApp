package com.opsc7312.quizwizapp

class LoginActivity {

}
